# ShriVista County — RajVista Ventures LLP

This package contains the compiled static site for **ShriVista County**, a premium residential gated community at **Akru, Dholera, Gujarat**, developed by **RajVista Ventures LLP**.

## Upload to Cloudflare Pages

1. Open **Cloudflare Dashboard → Workers & Pages → Create application → Pages → Upload assets**.
2. Upload the contents of the `cloudflare-upload` folder, or use `rajvista-shrivista-county-cloudflare.zip` where ZIP upload is supported.
3. Do not set a build command for this package. The site is already compiled.
4. Connect your custom domain from the Pages project settings.

The package includes the new Shri Vista County brochure, RajVista logo, and narrated Dholera video under `assets/`.

## Updated brochure details

The site now uses the supplied 21 October brochure, including:

- Akru, Dholera, Gujarat positioning
- Pre-launch price shown in the brochure: ₹10,999 per sq. yd.
- Project amenities: gated community, clubhouse, swimming pool, parks and green spaces, internal roads, water supply, electricity, jogging track, children's play area, and landscaped gardens
- Brochure location highlights: 1 km from Dholera SIR boundary, 6.6 km from Bhimnath Railway Junction, 400 m from Nabhoi Junction, 20 minutes from ABCD Building, 35 minutes from Dholera International Airport, and 10 minutes from approved DFC
- Brochure office: Unit No. 518, Tower B, Bhutani Alphathum, Sector 90, Noida 201305

Brochure figures are promotional and indicative. Confirm current distances, approvals, pricing, title, zoning, access and availability with the project team before publication or purchase.

## Current management designations

- Rahul Tyagi — Managing Partner & CEO
- Anubhav Jain — Designated Partner, Infrastructure
- Abhishek Tyagi — Designated Partner, Sales & Marketing

## Contact and WhatsApp

- +91 78272 40047
- +91 78278 90057
- +91 78278 90047
- +91 97111 85555
- WhatsApp sales enquiries: **+91 78272 40047**

## Updated project details

- Project location: Akru, Dholera, Gujarat
- Project map: https://goo.gl/maps/xXQu8kjuoXu5Ui2BA
- Office: Unit No. 518, Tower B, Bhutani Alphathum, Sector 90, Noida 201305

## Video

`assets/dholera-smart-city-2026-promo.mp4` is a 74-second 1280×720 H.264/AAC promotional film with English narration, ambient music, AI-generated conceptual aerial imagery, Dholera infrastructure themes, investment-context messaging, and a responsible due-diligence disclaimer. `assets/dholera-smart-city-2026-promo-poster.jpg` is the video poster.

## Dholera company context

The site includes a company and ecosystem section based on the supplied 2026 article and official Tata / Government of India references. Tata Electronics + PSMC is labelled as officially approved based on government and Tata announcements. Other names are explicitly labelled as reported, ecosystem participants, announced, proposed, planning-stage, or requiring verification. The site does not present every company as operational or as a guarantee of demand or returns.

Sources used in the website copy:

- Supplied list: https://dholerainsights.com/companies-investing-in-dholera-smart-city-2026/
- Government of India semiconductor release: https://www.pib.gov.in/PressReleasePage.aspx?PRID=2010132
- Tata Electronics announcement: https://www.tata.com/newsroom/business/first-indian-fab-semiconductor-dholera

## Verification note

Growth claims, company announcements, policies, approvals, distances, prices, availability, RERA status, title, zoning and timelines can change. Verify all claims with official sources and the project team before publishing or using the site for sales. The static enquiry form opens the visitor's email client and does not store submissions.
