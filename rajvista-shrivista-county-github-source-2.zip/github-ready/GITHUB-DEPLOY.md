# GitHub + Cloudflare Pages deployment

Create a GitHub repository and upload the contents of this folder. The package includes the updated Shri Vista County brochure, logo, narrated video, and poster under `client/public/assets/`.

```bash
git init
git add .
git commit -m "Update Shri Vista County brochure and content"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

In Cloudflare Pages, choose **Workers & Pages → Create application → Pages → Connect to Git** and use:

- Framework preset: **Vite**
- Build command: `pnpm install --frozen-lockfile && pnpm build`
- Build output directory: `dist/public`
- Node version: 20 or newer

Custom domain: after deployment, open the Pages project → **Custom domains** → **Set up a custom domain** and follow Cloudflare's DNS instructions.

Updated management: Rahul Tyagi — Managing Partner & CEO; Anubhav Jain — Designated Partner, Infrastructure; Abhishek Tyagi — Designated Partner, Sales & Marketing.

Updated sales contacts: +91 78272 40047, +91 78278 90057, +91 78278 90047, and +91 97111 85555. WhatsApp sales enquiries: +91 78272 40047.
