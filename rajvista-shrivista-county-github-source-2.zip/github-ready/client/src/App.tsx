import { useEffect, useState } from "react";
import {
  ArrowUpRight,
  Building2,
  CalendarDays,
  Check,
  ChevronDown,
  Compass,
  ExternalLink,
  Factory,
  Gem,
  Globe2,
  IndianRupee,
  LandPlot,
  Leaf,
  Linkedin,
  MapPinned,
  Menu,
  Milestone,
  Play,
  Phone,
  ShieldCheck,
  Sparkles,
  TrainFront,
  X,
} from "lucide-react";
import "./index.css";

const brochureImage = "/assets/brochure.jpg";
const rajvistaLogo = "/assets/rajvista-logo.png";
const promoVideo = "/assets/dholera-smart-city-2026-promo.mp4";
const promoPoster = "/assets/dholera-smart-city-2026-promo-poster.jpg";

const navItems = [
  { label: "The opportunity", href: "#opportunity" },
  { label: "Dholera story", href: "#dholera" },
  { label: "Companies", href: "#investments" },
  { label: "Management", href: "#management" },
  { label: "Enquire", href: "#enquire" },
];

const locationCards = [
  {
    icon: TrainFront,
    eyebrow: "RAIL",
    title: "Dedicated freight access",
    body: "Dholera sits within Gujarat's major industrial and logistics story, with rail and freight corridors planned to move people and goods efficiently.",
  },
  {
    icon: Factory,
    eyebrow: "INDUSTRY",
    title: "Built for the next economy",
    body: "Dholera SIR is planned as a greenfield industrial city with room for advanced manufacturing, electronics, renewables and high-value enterprise.",
  },
  {
    icon: Globe2,
    eyebrow: "CONNECTIVITY",
    title: "A strategic Gujarat address",
    body: "The region connects into the Delhi–Mumbai Industrial Corridor and Gujarat's established network of ports, highways and urban centres.",
  },
];

const dholeraSignals = [
  { icon: Factory, title: "Semiconductor & high-tech", body: "The document identifies Tata Electronics' semiconductor investment as a major signal in Dholera's advanced manufacturing story." },
  { icon: Milestone, title: "Plug-and-play infrastructure", body: "Planned underground utility corridors, smart grids and an Integrated Operations Center are part of the region's future-ready vision." },
  { icon: Leaf, title: "Clean energy at scale", body: "Solar and renewable-energy projects are positioned as a core part of Dholera's industrial and urban development narrative." },
  { icon: Globe2, title: "A 920 sq km canvas", body: "DSIR is planned at roughly 920 square kilometers within Gujarat's Delhi–Mumbai Industrial Corridor story." },
  { icon: Building2, title: "Data & technology hubs", body: "The supplied project material highlights data-center and AI-ready infrastructure proposals as emerging growth signals." },
  { icon: Compass, title: "Port-city heritage", body: "Dholera's story also reaches back to its historic identity as an ancient port city in the Gulf of Khambhat." },
];

const investmentCompanies = [
  { name: "Tata Electronics + PSMC", sector: "Semiconductor fab", status: "Officially approved", detail: "Up to ₹91,000 crore; planned capacity of 50,000 wafer starts per month.", tone: "confirmed" },
  { name: "L&T Vyom", sector: "AI-ready data centre", status: "Reported MoU / proposal", detail: "A reported 250 MW green data-centre campus proposal; verify current implementation status.", tone: "reported" },
  { name: "Tsingshan Holding Group", sector: "Steel & EV ecosystem", status: "Reported commitment", detail: "Reported interest in steel and EV-battery manufacturing within the wider Dholera story.", tone: "reported" },
  { name: "ReNew · Tata Power · Grew Energy", sector: "Clean energy", status: "Ecosystem participants", detail: "Renewables and solar-manufacturing names associated with the region's clean-energy narrative.", tone: "reported" },
  { name: "INOX Air Products", sector: "Industrial gases", status: "Reported presence", detail: "Industrial-gas supply is a key enabling layer for advanced manufacturing clusters.", tone: "reported" },
  { name: "Jabil · Micron · Mahindra Lifespaces", sector: "Electronics & urbanisation", status: "Reported / broader Gujarat ecosystem", detail: "Mentioned in the supplied 2026 list; project-specific Dholera status should be independently checked.", tone: "verify" },
  { name: "Tillman Global", sector: "Hyperscale data centre", status: "Announced / planning stage", detail: "A reported large-scale data-centre proposal; not presented here as operational or closed.", tone: "planning" },
  { name: "Adani Defence + Embraer", sector: "Aerospace", status: "MoU / location under discussion", detail: "Reported aerospace manufacturing initiative with Dholera described as a leading candidate location.", tone: "planning" },
];

const management = [
  {
    initials: "RT",
    name: "Rahul Tyagi",
    role: "Managing Partner & CEO",
    copy: "An entrepreneur and real estate services leader with experience starting and building companies across the property ecosystem. Rahul brings a long-horizon view to land development and customer trust.",
    tags: ["Founder mindset", "Land development", "Multi-state experience"],
    accent: "gold",
  },
  {
    initials: "AJ",
    name: "Anubhav Jain",
    role: "Designated Partner, Infrastructure",
    copy: "Focused on the infrastructure lens behind the development—helping translate Dholera's connectivity, utilities and industrial momentum into a grounded project story.",
    tags: ["Infrastructure", "Execution", "Project stewardship"],
    accent: "blue",
  },
  {
    initials: "AT",
    name: "Abhishek Tyagi",
    role: "Designated Partner, Sales & Marketing",
    copy: "Leads the people and customer-facing side of the venture, bringing clarity to enquiries, relationships and the experience of discovering ShriVista County.",
    tags: ["Sales", "People", "Customer experience"],
    accent: "terracotta",
  },
];

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="site-shell">
      <a className="skip-link" href="#main-content">Skip to content</a>
      <header className={`site-header ${scrolled ? "site-header--scrolled" : ""}`}>
        <div className="nav-wrap">
          <a href="#top" className="wordmark" aria-label="RajVista Ventures LLP — ShriVista County home">
            <img className="brand-logo" src={rajvistaLogo} alt="RajVista Ventures LLP" />
            <span className="project-lockup"><strong>SHRIVISTA</strong><em>COUNTY · DHOLERA</em></span>
          </a>
          <nav className={`desktop-nav ${menuOpen ? "desktop-nav--open" : ""}`} aria-label="Primary navigation">
            {navItems.map((item) => (
              <a key={item.href} href={item.href} onClick={() => setMenuOpen(false)}>{item.label}</a>
            ))}
            <a className="nav-cta" href="#enquire">Book a conversation <ArrowUpRight size={16} /></a>
          </nav>
          <button className="menu-toggle" onClick={() => setMenuOpen((current) => !current)} aria-label={menuOpen ? "Close menu" : "Open menu"} aria-expanded={menuOpen}>
            {menuOpen ? <X size={21} /> : <Menu size={21} />}
          </button>
        </div>
      </header>

      <main id="main-content">
        <section className="hero" id="top">
          <div className="hero-orb hero-orb--one" />
          <div className="hero-orb hero-orb--two" />
          <div className="hero-grid" />
          <div className="hero-content container">
            <div className="hero-copy">
              <div className="eyebrow eyebrow--light"><span className="eyebrow-line" /> RAJVISTA VENTURES LLP · AKRU, DHOLERA · GUJARAT <span className="eyebrow-dot" /></div>
              <h1>Invest in a <em>smarter</em> tomorrow.</h1>
              <p className="hero-lede">A premium residential gated community by RajVista Ventures LLP, positioned near the infrastructure, industry and ambition of Dholera SIR.</p>
              <div className="hero-actions">
                <a className="button button--gold" href="#opportunity">Explore the opportunity <ArrowUpRight size={17} /></a>
                <a className="text-link text-link--light" href="#location">See the location <ChevronDown size={16} /></a>
                <a className="text-link text-link--light" href="#film">Watch the project film <Play size={15} fill="currentColor" /></a>
              </div>
              <div className="hero-microcopy"><ShieldCheck size={15} /> Thoughtful planning · Premium plots · Long-term perspective</div>
            </div>
            <div className="hero-art">
              <div className="hero-art-frame">
                <img src={brochureImage} alt="Shri Vista County promotional brochure showing the community entrance and Dholera location advantages" />
              </div>
              <div className="hero-art-note"><span>01</span><div><strong>Dholera SIR</strong><small>The future of India's growth</small></div></div>
            </div>
          </div>
          <div className="hero-bottom container">
            <div className="scroll-cue"><span className="scroll-cue-line" /> Scroll to discover</div>
            <div className="hero-stat"><span className="hero-stat-number">35<span>+</span></span><span className="hero-stat-label">years of combined<br />real estate experience</span></div>
          </div>
        </section>

        <section className="promo-section" id="film">
          <div className="container promo-grid">
            <div className="promo-copy">
              <div className="section-kicker"><span>01</span><span className="kicker-line" /> Project film</div>
              <h2>See the story<br /><em>in motion.</em></h2>
              <p>A narrated visual introduction to Dholera's growth platform, the companies shaping its ecosystem and ShriVista County at 89 Akru.</p>
              <a className="button button--outline" href={promoVideo} target="_blank" rel="noreferrer">Open promotion video <ExternalLink size={15} /></a>
            </div>
            <div className="promo-video-frame">
              <video controls playsInline preload="metadata" poster={promoPoster} aria-label="ShriVista County promotional video">
                <source src={promoVideo} type="video/mp4" />
                Your browser does not support embedded video. <a href={promoVideo}>Open the promotion video</a>.
              </video>
              <div className="promo-video-label"><Play size={13} fill="currentColor" /> 74 sec · narrated Dholera story</div>
            </div>
          </div>
        </section>

        <section className="intro-section" id="opportunity">
          <div className="container intro-grid">
            <div className="section-kicker"><span>01</span><span className="kicker-line" /> The opportunity</div>
            <div className="intro-copy">
              <p className="display-title">A location with <em>momentum.</em></p>
              <p className="body-large">ShriVista County is created for buyers who recognise the value of getting close to the story before it becomes obvious. Developed by RajVista Ventures LLP, it brings a premium gated-community idea to the edge of Dholera's next chapter.</p>
              <div className="intro-points">
                <div><Check size={16} /><span>Premium plotted living in Akru, Gujarat</span></div>
                <div><Check size={16} /><span>Positioned near Dholera SIR's growth ecosystem</span></div>
                <div><Check size={16} /><span>Designed around access, green space and community</span></div>
              </div>
              <a className="text-link text-link--dark" href="#location">Why Dholera, now? <ArrowUpRight size={16} /></a>
            </div>
            <div className="intro-aside">
              <div className="aside-number">01</div>
              <p>“The best addresses are not only found. They are recognised early.”</p>
              <div className="aside-rule" />
              <small>SHRI VISTA COUNTY · AKRU</small>
            </div>
          </div>
        </section>

        <section className="feature-band">
          <div className="container feature-grid">
            <div className="feature-image-wrap">
              <img src={brochureImage} alt="Shri Vista County brochure detail with location advantages and community amenities" />
              <div className="image-caption"><span>SHRI VISTA COUNTY</span><span>PREMIUM PLOTS · MODERN LIVING</span></div>
            </div>
            <div className="feature-copy">
              <div className="eyebrow"><span className="eyebrow-line" /> A community with intent</div>
              <h2>Room to grow into <em>what's next.</em></h2>
              <p>From gated-community living and wide internal roads to water supply, drainage, parks and green spaces, the vision is simple: make the future feel tangible today.</p>
              <div className="feature-metrics">
                <div><LandPlot size={20} /><strong>Premium plots</strong><span>For an address with room to breathe</span></div>
                <div><Leaf size={20} /><strong>Green-minded living</strong><span>Parks, landscaped gardens and everyday ease</span></div>
                <div><Building2 size={20} /><strong>Everyday infrastructure</strong><span>Water supply, drainage and wide internal roads</span></div>
                <div><Gem size={20} /><strong>Value with vision</strong><span>Buy into a corridor with momentum</span></div>
              </div>
            </div>
          </div>
        </section>

        <section className="location-section" id="location">
          <div className="container">
            <div className="section-heading-row">
              <div><div className="section-kicker"><span>02</span><span className="kicker-line" /> Location intelligence</div><h2>Why <em>Dholera?</em></h2></div>
              <p>Dholera SIR is one of Gujarat's most ambitious planned urban and industrial growth stories. Shri Vista County places your next chapter within its orbit.</p>
            </div>
            <div className="location-cards">
              {locationCards.map((card) => {
                const Icon = card.icon;
                return <article className="location-card" key={card.title}><div className="card-icon"><Icon size={22} strokeWidth={1.7} /></div><div className="card-eyebrow">{card.eyebrow}</div><h3>{card.title}</h3><p>{card.body}</p><a href="https://dholera.gujarat.gov.in/" target="_blank" rel="noreferrer" aria-label={`Learn more about ${card.title}`}>Explore the official story <ExternalLink size={14} /></a></article>;
              })}
            </div>
            <div className="map-layout">
              <div className="map-panel">
                <div className="map-topline"><span><MapPinned size={16} /> Indicative location map</span><span>Akru · Gujarat</span></div>
                <div className="map-frame">
                  <iframe title="Map showing 89 Akru, Gujarat" src="https://www.google.com/maps?q=89%20Akru%2C%20Gujarat&z=14&output=embed" loading="lazy" referrerPolicy="no-referrer-when-downgrade" />
                  <div className="map-overlay"><div className="map-pin"><MapPinned size={18} /></div><strong>ShriVista County</strong><span>Akru, Dholera, Gujarat</span></div>
                </div>
                <div className="map-footnote">Map is indicative. Please confirm exact parcel location, distances and approvals with the project team before making a purchase decision.</div>
              </div>
              <div className="journey-panel">
                <div className="section-kicker"><span>03</span><span className="kicker-line" /> The journey</div>
                <h3>Close to the <em>connections</em> that matter.</h3>
                <p>Use the brochure's indicative drive-time story as a starting point, then let our team give you the current, on-ground picture.</p>
                <div className="journey-list">
                  <div><span className="journey-time">01</span><span><strong>Dholera SIR boundary</strong><small>Indicative proximity shown in brochure</small></span></div>
                  <div><span className="journey-time">02</span><span><strong>Rail & freight network</strong><small>Designed for regional movement and access</small></span></div>
                  <div><span className="journey-time">03</span><span><strong>Future-ready ecosystem</strong><small>Industry, infrastructure and new enterprise</small></span></div>
                </div>
                <a className="button button--outline" href="https://goo.gl/maps/xXQu8kjuoXu5Ui2BA" target="_blank" rel="noreferrer">Open Akru project location <ArrowUpRight size={16} /></a>
              </div>
            </div>
          </div>
        </section>

        <section className="dholera-story" id="dholera">
          <div className="container">
            <div className="section-heading-row story-heading"><div><div className="section-kicker"><span>04</span><span className="kicker-line" /> The Dholera story</div><h2>More than a location.<br /><em>A growth platform.</em></h2></div><p>Dholera is planned as a greenfield industrial smart city within Gujarat's Ahmedabad district and the Delhi–Mumbai Industrial Corridor. These are the growth signals shaping the region's next decade.</p></div>
            <div className="story-grid">
              {dholeraSignals.map((signal) => { const Icon = signal.icon; return <article className="story-card" key={signal.title}><div className="story-icon"><Icon size={21} strokeWidth={1.7} /></div><h3>{signal.title}</h3><p>{signal.body}</p></article>; })}
            </div>
            <div className="authority-strip"><div><span className="authority-label">PLANNING & DELIVERY</span><strong>Government of Gujarat · Government of India · DICDL · DSIRDA</strong></div><a href="https://dholera.gujarat.gov.in/" target="_blank" rel="noreferrer">Explore official Dholera resources <ExternalLink size={14} /></a></div>
            <p className="story-disclaimer">Growth signals and agency references are summarised from the supplied RajVista project brief. Please independently verify current status, investment announcements, policies, approvals, distances and timelines before relying on them.</p>
          </div>
        </section>

        <section className="investment-section" id="investments">
          <div className="container">
            <div className="section-heading-row investment-heading"><div><div className="section-kicker"><span>05</span><span className="kicker-line" /> Companies & ecosystem</div><h2>Who is shaping<br /><em>Dholera's next chapter?</em></h2></div><p>Selected names from the supplied “Companies Investing in Dholera Smart City 2026” article, cross-checked against official Tata and Government of India material where available.</p></div>
            <div className="investment-grid">{investmentCompanies.map((company) => <article className="investment-card" key={company.name}><div className="investment-card-top"><span className={`status-pill status-pill--${company.tone}`}>{company.status}</span><span className="investment-sector">{company.sector}</span></div><h3>{company.name}</h3><p>{company.detail}</p></article>)}</div>
            <div className="investment-sources"><span>Sources</span><a href="https://dholerainsights.com/companies-investing-in-dholera-smart-city-2026/" target="_blank" rel="noreferrer">Supplied 2026 company list <ExternalLink size={13} /></a><a href="https://www.pib.gov.in/PressReleasePage.aspx?PRID=2010132" target="_blank" rel="noreferrer">Government of India semiconductor release <ExternalLink size={13} /></a><a href="https://www.tata.com/newsroom/business/first-indian-fab-semiconductor-dholera" target="_blank" rel="noreferrer">Tata Electronics announcement <ExternalLink size={13} /></a></div>
            <p className="story-disclaimer">Investment names and statuses are presented for context, not as guarantees of future demand or returns. Announced, proposed, planning-stage, ecosystem and operational status can change. Verify title, approvals, zoning, access, RERA status, project-specific claims and current company activity independently before making a purchase.</p>
          </div>
        </section>

        <section className="management-section" id="management">
          <div className="container">
            <div className="section-heading-row management-heading"><div><div className="section-kicker section-kicker--light"><span>06</span><span className="kicker-line" /> The people behind the place</div><h2>Experience that <em>grounds the vision.</em></h2></div><p>Our management team brings more than <strong>25 years of experience in real estate services</strong>, including land development projects across multiple states in India. Together, Rahul Tyagi, Anubhav Jain and Abhishek Tyagi bring <strong>35+ years of combined real estate development experience.</strong></p></div>
            <div className="management-grid">
              {management.map((person) => <article className={`person-card person-card--${person.accent}`} key={person.initials}><div className="person-top"><div className="initials">{person.initials}</div><span className="person-number">/ {person.initials === "RT" ? "01" : person.initials}</span></div><div className="person-role">{person.role}</div><h3>{person.name}</h3><p>{person.copy}</p><div className="tag-row">{person.tags.map((tag) => <span key={tag}>{tag}</span>)}</div>{person.name === "Rahul Tyagi" && <a className="linkedin-link" href="#enquire"><Linkedin size={15} /> Request leadership profile <ArrowUpRight size={13} /></a>}</article>)}
            </div>
            <div className="management-note"><ShieldCheck size={18} /><span>Management details are based on the supplied RajVista Ventures LLP project brief. Confirm credentials, registrations and current roles before publication.</span></div>
          </div>
        </section>

        <section className="contact-section" id="enquire">
          <div className="contact-glow" />
          <div className="container contact-grid">
            <div className="contact-copy"><div className="section-kicker section-kicker--light"><span>07</span><span className="kicker-line" /> Start a conversation</div><h2>Your future address<br />starts with a <em>conversation.</em></h2><p>Tell us what you are looking for, and our team will share the project story, availability and next steps.</p><div className="contact-details"><a href="tel:+917827240047"><Phone size={17} /> +91 78272 40047</a><a href="tel:+917827890057"><Phone size={17} /> +91 78278 90057</a><a href="tel:+917827890047"><Phone size={17} /> +91 78278 90047</a><a href="tel:+919711185555"><Phone size={17} /> +91 97111 85555</a><a href="https://wa.me/917827240047?text=Hello%20ShriVista%20County%20team%2C%20I%20would%20like%20more%20information." target="_blank" rel="noreferrer"><Phone size={17} /> WhatsApp enquiries · +91 78272 40047</a><span><MapPinned size={17} /> Project location · Akru, Dholera, Gujarat</span><span><MapPinned size={17} /> Office · Unit No. 518, Tower B, Bhutani Alphathum, Sector 90, Noida 201305</span></div></div>
            <div className="enquiry-card"><div className="enquiry-header"><span>PRIVATE ENQUIRY</span><CalendarDays size={20} /></div><h3>Request the project brief</h3><p>We'll connect you with the RajVista Ventures LLP team.</p><form onSubmit={(event) => { event.preventDefault(); window.location.href = "mailto:info@shrivistacounty.com?subject=Shri Vista County enquiry"; }}><label><span>Your name</span><input required name="name" placeholder="Enter your name" /></label><label><span>Mobile number</span><input required name="phone" type="tel" placeholder="+91" /></label><button className="button button--gold button--full" type="submit">Request a call <ArrowUpRight size={17} /></button><small>By enquiring, you agree to be contacted about ShriVista County by RajVista Ventures LLP. This form opens your email client and does not store data.</small></form></div>
          </div>
        </section>
      </main>

        <footer className="site-footer"><div className="container footer-top"><a href="#top" className="wordmark wordmark--footer"><img className="brand-logo" src={rajvistaLogo} alt="RajVista Ventures LLP" /><span className="project-lockup"><strong>SHRIVISTA</strong><em>COUNTY · DHOLERA</em></span></a><p>RajVista Ventures LLP<br />Developers & Builders · LLP No. ADB - 8681</p><div className="footer-links"><a href="#opportunity">Opportunity</a><a href="#dholera">Dholera story</a><a href="#investments">Companies</a><a href="#management">Management</a><a href="#enquire">Enquire</a></div></div><div className="container footer-bottom"><span>© {new Date().getFullYear()} RajVista Ventures LLP. All rights reserved.</span><span>Information is indicative and subject to verification, approvals and availability.</span></div></footer>
    </div>
  );
}

export default App;
